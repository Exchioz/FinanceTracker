"use client"

import { useEffect, useState } from "react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { List, Home, Tags, Wallet, BarChart, DollarSign, Settings } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar"
import { NavUser } from "@/components/nav-user"
import { Switch } from "./ui/switch"

const items = [
  { title: "Dashboard", icon: Home, url: "/dashboard" },
  { title: "Transactions", icon: List, url: "/transactions" },
  { title: "Categories", icon: Tags, url: "/categories" },
  { title: "Accounts", icon: Wallet, url: "/accounts" },
  { title: "Reports", icon: BarChart, url: "/reports" },
  { title: "Budgets", icon: DollarSign, url: "/budgets" },
  { title: "Settings", icon: Settings, url: "/settings" },
]

export function AppSidebar() {
  const supabase = createClientComponentClient()
  const [user, setUser] = useState<{ name?: string; email?: string; avatarUrl?: string} | null>(null)

  useEffect(() => {
    const getUser = async () => {
      const { data, error } = await supabase.auth.getUser()
      if (data?.user) {
        setUser({
          name: data.user.user_metadata?.name ?? "User",
          email: data.user.email ?? "@.com",
          avatarUrl: data.user.user_metadata?.avatar_url ?? undefined
        })
      }
    }
    getUser()
  }, [supabase])

  return (
    <Sidebar>
      <SidebarContent>
        <div className="px-4 py-6 text-lg font-bold">Finance Tracker</div>
        <SidebarGroup>
          <SidebarGroupLabel>Application</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <a href={item.url}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        {user && <NavUser user={user} />}
        <div className="flex items-center justify-between px-3 py-2">
          <span className="text-xs text-muted-foreground">Dark Mode</span>
          <Switch />
        </div>
        <p className="text-[10px] text-muted-foreground px-3">v1.0.0</p>
      </SidebarFooter>
    </Sidebar>
  )
}
