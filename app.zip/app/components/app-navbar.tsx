'use client'

import { useTheme } from "next-themes"
import { SunIcon, MoonIcon, BellIcon } from "lucide-react"
import { Button } from "./ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@radix-ui/react-avatar"

export function AppNavbar() {
    const { setTheme, theme } = useTheme()

    return (
        <header className="w-full flex items-center justify-between border-b bg-background px-6 py-4">
            <div className="text-xl font-semibold">Dashboard</div>

            <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon">
                <BellIcon className="w-5 h-5" />
                </Button>

                <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                >
                {theme === "dark" ? <SunIcon className="w-5 h-5" /> : <MoonIcon className="w-5 h-5" />}
                </Button>

                <Avatar className="h-8 w-8">
                <AvatarImage src="/avatar.png" />
                <AvatarFallback>IR</AvatarFallback>
                </Avatar>
            </div>
        </header>
    )
}