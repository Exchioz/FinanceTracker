import { AppNavbar } from "@/components/app-navbar"
import { AppSidebar } from "@/components/app-sidebar"
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen">
        <AppSidebar />
        <div className="flex flex-col flex-1">
          <AppNavbar/>
          <main className="flex-1 p-6 space-y-4">
            <SidebarTrigger />
            {children}
          </main>
        </div>

      </div>
    </SidebarProvider>
  )
}