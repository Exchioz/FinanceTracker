'use client'

import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { useRouter } from 'next/navigation'

export default function Signup() {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [loading, setLoading] = useState(false)
    const router = useRouter()

    const handleSignup = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)

        try {
        const { error } = await supabase.auth.signUp({
            email,
            password,
        })
        if (error) throw error
        router.push('/dashboard') // Redirect manual setelah signup berhasil
        } catch (error) {
        console.error('Signup error:', error)
        } finally {
        setLoading(false)
        }
    }

    return (
        <div>
        <h1>Sign Up</h1>
        <form onSubmit={handleSignup}>
            <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            required
            />
            <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            required
            />
            <button type="submit" disabled={loading}>
            {loading ? 'Loading...' : 'Sign Up'}
            </button>
        </form>
        </div>
    )
}