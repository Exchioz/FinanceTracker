'use client'

import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { useRouter } from 'next/navigation'

export default function Auth({ type }: { type: 'login' | 'signup' }) {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [loading, setLoading] = useState(false)
    const [errorMsg, setErrorMsg] = useState('')
    const router = useRouter()

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)
        setErrorMsg('')

        try {
        if (type === 'signup') {
            const { error } = await supabase.auth.signUp({ email, password })
            if (error) throw error
            router.push('/dashboard')
        } else {
            const { data, error } = await supabase.auth.signInWithPassword({ email, password })
            if (error) throw error
            if (data.user) {
                window.location.href = '/dashboard' // hard redirect
            }
        }
        } catch (error: any) {
        console.error('Auth error:', error.message)
        setErrorMsg(error.message || 'Terjadi kesalahan saat proses autentikasi.')
        } finally {
        setLoading(false)
        }
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-4 max-w-sm mx-auto">
        <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            required
            className="w-full p-2 border rounded"
        />
        <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            required
            className="w-full p-2 border rounded"
        />
        {errorMsg && (
            <p className="text-red-600 text-sm text-center">{errorMsg}</p>
        )}
        <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
        >
            {loading ? 'Loading...' : type === 'login' ? 'Login' : 'Sign Up'}
        </button>
        {type === 'login' && (
            <p className="text-sm text-center mt-4">
            Belum punya akun?{' '}
            <a href="/signup" className="text-blue-600 underline">
                Daftar
            </a>
            </p>
        )}
        </form>
    )
}
